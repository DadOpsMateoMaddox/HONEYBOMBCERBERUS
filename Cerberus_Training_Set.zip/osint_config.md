
# OSINT Enrichment Configuration

## GreyNoise
API_KEY=grn_xxxxxxxxxxxxxxxxxxxxx
Query: `curl -H 'key: $API_KEY' https://api.greynoise.io/v3/community/IP`

## AbuseIPDB
API_KEY=abuse_xxxxxxxxxxxxxxxxxx
Query: `curl -G https://api.abuseipdb.com/api/v2/check --data-urlencode 'ipAddress=1.2.3.4' -H 'Key: $API_KEY'`

## Shodan
API_KEY=shodan_xxxxxxxxxxxxxxxxx
Query: `shodan host IP`
